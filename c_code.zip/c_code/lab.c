//Install a C compiler on your system and configure the IDE. Write your first program to print 
//"Hello, World!" and run it. 

#include <stdio.h> 
int main() { 

printf("HELLO WORLD"); 
return 0; 
} 